# Studentportfoliotemplate

# This is a template for student portfolio website.

# All students must make modifications and use their images on the portfolio website to show that the you can do rapid development and rapid deployment for the purpose of the dev ops course we intend to use this for.